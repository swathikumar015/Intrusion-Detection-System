from scapy.all import sniff, IP, TCP, UDP, DNS, DNSRR
import socket
import threading
import struct
import time
from collections import defaultdict

from scapy.all import conf
conf.max_list_count = 10000  # packet limit

# IDS thresholds
PORT_SCAN_THRESHOLD = 10 #ports
SYN_FLOOD_THRESHOLD = 50 #packets
TIME_WINDOW = 10

# Trackers
port_scan_tracker = defaultdict(list)
syn_flood_tracker = defaultdict(list)
dns_response_tracker = defaultdict(set)

#Intrusion Detection 
def detect_intrusions(packet):
    current_time = time.time()

    
    if packet.haslayer(IP) and packet.haslayer(TCP):
        ip_src = packet[IP].src
        port = packet[TCP].dport
        flags = packet[TCP].flags

        if flags == 2:  # SYN
            port_scan_tracker[ip_src].append((port, current_time)) #port and time 
            port_scan_tracker[ip_src] = [p for p in port_scan_tracker[ip_src] if p[1] > current_time - TIME_WINDOW]
            unique_ports = {p[0] for p in port_scan_tracker[ip_src]}
            if len(unique_ports) > PORT_SCAN_THRESHOLD:
                print(f"🚨 Port Scan Detected from {ip_src}")
                port_scan_tracker[ip_src] = []

            syn_flood_tracker[ip_src].append(current_time) # time
            syn_flood_tracker[ip_src] = [t for t in syn_flood_tracker[ip_src] if t > current_time - TIME_WINDOW]
            if len(syn_flood_tracker[ip_src]) > SYN_FLOOD_THRESHOLD:
                print(f"🚨 SYN Flood Attack Detected from {ip_src}")
                syn_flood_tracker[ip_src] = []

    #  DNS Spoofing 
    if packet.haslayer(DNS) and packet.haslayer(DNSRR):
        ip_src = packet[IP].src
        try:
            dns_qname = packet[DNS].qd.qname.decode() if packet[DNS].qd else ""
        except:
            return

        dns_ans = packet[DNSRR].rdata if packet[DNSRR] else None

        if "._tcp.local." in dns_qname:
            return

        if dns_qname and dns_ans:
            dns_response_tracker[dns_qname].add(dns_ans)
            if len(dns_response_tracker[dns_qname]) > 1:
                print(f"🚨 DNS Spoofing Detected for {dns_qname}")
                print(f"    IPs seen: {dns_response_tracker[dns_qname]}")


def raw_socket_listener(): # sets up a raw socket bound to  IP and prints every incoming packet’s length
    try:
        print("🧪 Raw Socket Listening (tap)...")
        rsock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_IP)
        rsock.bind(("10.1.18.43", 0))  # Mac IP
        rsock.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
        while True:
            pkt = rsock.recvfrom(65535)[0]
            print(f"📦 Raw socket captured {len(pkt)} bytes")  
    except Exception as e:
        print("⚠️ Raw socket error:", e)
        print("💡 Run with sudo if not already.")


def main():
    print("🔍 IDS Running... Monitoring Port Scans, SYN Floods, and DNS Spoofing")

    # Start raw socket listener 
    raw_thread = threading.Thread(target=raw_socket_listener, daemon=True)
    raw_thread.start()

    # Start  sniffing
    sniff(filter="ip and not udp port 5353", prn=detect_intrusions, store=0)

if __name__ == "__main__":
    main()